-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 15, 2018 at 05:29 AM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `assessment`
--

-- --------------------------------------------------------

--
-- Table structure for table `assessment`
--

DROP TABLE IF EXISTS `assessment`;
CREATE TABLE IF NOT EXISTS `assessment` (
  `assessment_id` int(11) NOT NULL AUTO_INCREMENT,
  `assessment_token` varchar(50) NOT NULL,
  `assessment_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `account_name` varchar(50) NOT NULL,
  `project_name` varchar(50) NOT NULL,
  `automation_status` varchar(25) NOT NULL,
  `devops_platform` varchar(25) NOT NULL,
  `summary` text NOT NULL,
  `quick_notes` text NOT NULL,
  `assessed_by` int(11) DEFAULT NULL,
  `status` varchar(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`assessment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `assessment_environments`
--

DROP TABLE IF EXISTS `assessment_environments`;
CREATE TABLE IF NOT EXISTS `assessment_environments` (
  `assessment_environment_id` int(11) NOT NULL AUTO_INCREMENT,
  `assessment_id` int(11) NOT NULL,
  `environment` varchar(50) NOT NULL,
  `applicable` tinyint(4) NOT NULL COMMENT 'true = 1 and false =0',
  `managed_by` varchar(50) NOT NULL,
  `auto_deploy` varchar(100) NOT NULL,
  `remarks` text NOT NULL,
  PRIMARY KEY (`assessment_environment_id`),
  KEY `assessment_id` (`assessment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=306 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `assessment_phase`
--

DROP TABLE IF EXISTS `assessment_phase`;
CREATE TABLE IF NOT EXISTS `assessment_phase` (
  `assessment_phase_id` int(11) NOT NULL AUTO_INCREMENT,
  `assessment_id` int(11) NOT NULL,
  `phase_id` int(11) NOT NULL,
  `phase_name` varchar(50) NOT NULL,
  `automation_status` varchar(25) NOT NULL,
  `processes` text NOT NULL,
  `automation_satisfaction` varchar(25) NOT NULL,
  `observations` text NOT NULL,
  `reasons` text NOT NULL,
  `special_remarks` text NOT NULL,
  PRIMARY KEY (`assessment_phase_id`),
  KEY `assessment_id` (`assessment_id`),
  KEY `phase_id` (`phase_id`)
) ENGINE=InnoDB AUTO_INCREMENT=550 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `assessment_phase_tools`
--

DROP TABLE IF EXISTS `assessment_phase_tools`;
CREATE TABLE IF NOT EXISTS `assessment_phase_tools` (
  `assessment_phase_tool_id` int(11) NOT NULL AUTO_INCREMENT,
  `assessment_phase_id` int(11) NOT NULL,
  `assessment_id` int(11) NOT NULL,
  `tool_name` varchar(50) NOT NULL,
  `version` varchar(50) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`assessment_phase_tool_id`),
  KEY `assessment_phase_id` (`assessment_phase_id`),
  KEY `assessment_id` (`assessment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=529 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `assessment_recommendations`
--

DROP TABLE IF EXISTS `assessment_recommendations`;
CREATE TABLE IF NOT EXISTS `assessment_recommendations` (
  `assessment_recommendation_id` int(11) NOT NULL AUTO_INCREMENT,
  `assessment_id` int(11) NOT NULL,
  `title` text,
  `description` text,
  `added_on` datetime NOT NULL,
  PRIMARY KEY (`assessment_recommendation_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `master_phase`
--

DROP TABLE IF EXISTS `master_phase`;
CREATE TABLE IF NOT EXISTS `master_phase` (
  `phase_id` int(11) NOT NULL AUTO_INCREMENT,
  `phase_identity` varchar(50) NOT NULL,
  `phase_name` varchar(50) NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`phase_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_phase`
--

INSERT INTO `master_phase` (`phase_id`, `phase_identity`, `phase_name`, `is_active`) VALUES
(1, 'planning_tools', 'Planning Tools', 1),
(2, 'source_code_management', 'Source Code Management', 1),
(3, 'continuous_integration', 'Continuous Integration', 1),
(4, 'package_management', 'Binary Repository / Package Management', 1),
(5, 'infra_provisioning', 'Infrastructure Provisioning', 1),
(6, 'continuous_delivery_dev', 'Continuous Delivery (Dev/SIT)', 1),
(7, 'continuous_delivery_uat', 'Continuous Delivery (UAT)', 1),
(8, 'continuous_deployment', 'Continuous Deployment', 1),
(9, 'continuous_monitoring', 'Continuous Monitoring', 1);

-- --------------------------------------------------------

--
-- Table structure for table `master_tool`
--

DROP TABLE IF EXISTS `master_tool`;
CREATE TABLE IF NOT EXISTS `master_tool` (
  `tool_id` int(11) NOT NULL AUTO_INCREMENT,
  `tool_identity` varchar(50) NOT NULL,
  `tool_name` varchar(50) NOT NULL,
  `version` varchar(11) DEFAULT NULL,
  `description` text,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`tool_id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_tool`
--

INSERT INTO `master_tool` (`tool_id`, `tool_identity`, `tool_name`, `version`, `description`, `is_active`) VALUES
(1, 'JIRA', 'Atlassian JIRA', '', '1) JIRA for Agile Application Management tool.\r\n2) Task Management to track simple tasks\r\n3) View Project status without having to email or set up a meeting\r\n4) Project Management feature allows to organizes corporate website designs or employee training programs\r\n5) Measure performance in different ways for quick overview and pre-defined report\r\n6) Use out-of-the-box templates or customize them according to specific business needs', 1),
(2, 'GIT', 'Git', '', '1) Feature rich branching\r\n2) Feature Based Workflow allows new branches for each new feature and seamlessly switch back and forth between them.\r\n3) Fast as nearly all operations are performed locally, giving it a huge speed advantage on centralized systems that constantly have to communicate with a server somewhere.\r\n4) Distributed SCM gives flexibility of doing a \"checkout\" of the current tip of the source code, and \"clone\" of the entire repository.\r\n5) Git ensures the cryptographic integrity of every bit of your project.\r\n6) Git uses concept of \"staging area\" or \"index\". An intermediate area where commits can be formatted and reviewed before completing the commit', 1),
(3, 'SVN', 'SVN', '', '1) Branching and tagging are easy operations.\r\n2) Automated assistance with managing the flow of changes between lines of development, and with the merging of branches back into their sources.\r\n3) File locking (exclusive) notification 4) Subversion command-line client (svn) offers various ways to resolve conflicting changes, include interactive resolution prompting.', 1),
(4, 'VSTS', 'VSTS', '', '1)  Support two types of source control: Git (distributed) and Team Foundation Version Control (TFVC).', 1),
(5, 'Confluence', 'Confluence', '', '', 1),
(6, 'version_one', 'VersionOne', '', '1) Prioritize stories and defects using the drag-and-drop function.\r\n2) Group Items by theme\r\n3) Capture all Feature Requests in One Place\r\n4) Ensure alignment between corporate objectives and product deliverables\r\n5) forum for engaging with other customers to learn from peers.\r\n6) Provides insights and end to end visibility.', 1),
(7, 'aldon', 'Aldon', '', '1) Aldon Lifecycle Manager (Automate IT and DevOps workflow)\r\n2) Helps reduce software errors and avoid production outages\r\n3) Streamlined change management \r\n4) Resolve deployment issues remotely\r\n5) Simple build integration on any version control application\r\n6) Allows single-click code promotion\r\n7) Automatic inventory of builds and packaging\r\n9) Role-based and individual permission definitions\r\n10) Control and management of all servers from single console', 1),
(8, 'tech_excel', 'TechExcel - Dev Suite', '', '1) fully integrated ALM solution\r\n2) Full traceability of requirements\r\n3) Workflow Automation & Standardization\r\n4) Manage test cases, plan for test coverage, and control test execution\r\n5) Scalability and performance\r\n6) Personalized user experience\r\n7) Simplify product planning with the help of a centralized view', 1),
(9, 'rally', 'Rally', '', '1) Rally Enterprise and Community Editions\r\n2) Offers web-based ALM platform that can be accessed from a browser like chrome or safari etc through an operating system like Windows or Linux.\r\n3) Used by organizations of all sizes like small or medium or large-scale that develops the applications with agile methodology.\r\n4) Enterprise level platform used for scaling agile development methodologies in a project.\r\n5) Real-time project metrics like performance metrics, productivity, quality and openness of the applications can be measured.', 1),
(10, 'cvs', 'CVS', '', '1) Uses a client–server architecture:\r\n2) Supports Unix and Windows?\r\n3) Allows multuple branches of the project\r\n4) Uses delta compression for efficient storage of different versions of the same file.', 1),
(11, 'apache_subversion', 'Apache SubVersion', '', '', 1),
(12, 'ms_build', 'MS Build', '', '1) Integrated as the build system foundation for all the new .NET Tooling', 1),
(13, 'angular_cli', 'Angular Cli', '', '1) For Angular projects, the Angular CLI defaults to creating and running unit tests using Jasmine and Karma.', 1),
(14, 'gradle', 'Gradle', '', '1) Build automation system that builds upon concepts of Apache Ant and Apache Maven \r\n2) Uses Groovy-based domain-specific language (DSL) instead of the XML form\r\n3) Designed for multi-project builds, \r\n4) Plugins support focused on Java, Groovy and Scala development and deployment.', 1),
(15, 'maven', 'Maven', '', '1)  Uniform build system & Parallel Builds\r\n2) Error and Integrity Reporting\r\n3) Unit test reports including coverage', 1),
(16, 'jenkins', 'Jenkins', '', '1) Java based continuous integration tool\r\n2) cross-platform CI tool and it offers configuration both through GUI interface and console commands.\r\n3) feature extension through plugins\r\n4) Provides flexibility of distributing builds and test loads on multiple machines\r\n5) Jenkins has to be associated with a version control system like GitHub or SVN. \r\n6) Used for application provisioning and deployment.\r\n7) Provides ease of building and testing software projects continuously.\r\n8) Easily integrate the changes and release them\r\n9) Integrates with almost every SCM/Build tools\r\n10) Distribute build or test activities across multiple systems even when they are running on different operating systems.\r\n11) Uses MIT License - free to use and distribute', 1),
(17, 'sonarqube', 'SonarQube', '', '1) Deep Code Analysis\r\n2) Greater Insights\r\n3) Continuous Inspection\r\n4) Enforce code quality practice across all teams through Quality Gate.\r\n5) Track quality of short-lived and long-lived code branches to ensure only clean, approved code gets merged into master.', 1),
(18, 'jasmine', 'Jasmine', '', '1) Javascript testing framework that supports software development practice called Behaviour Driven Development or BDD.\r\n2) Jasmine comes with a few pre-built matchers', 1),
(19, 'mockito', 'Mockito', '', '', 1),
(20, 'junit', 'JUnit', '', '', 1),
(21, 'nunit', 'NUnit', '', '1)  Unit testing framework for Microsoft .NET\r\n2) Integrated with Visual Studio\r\n3) Support for data driven tests\r\n4) Supports multiple platforms .NET Core, Xamarin Mobile, Compact Framework\r\n5) Provision for batch running of tests', 1),
(22, 'nuget', 'Nuget', '', '', 1),
(23, 'myget', 'MyGet', '', '', 1),
(24, 'npm', 'NPM', '', '', 1),
(25, 'composer', 'Composer', '', '', 1),
(26, 'bower', 'Bower', '', '', 1),
(27, 'vm', 'VMs', '', '', 1),
(28, 'desired_state_configuration', 'Desired State Configuration', '', '', 1),
(29, 'azure_resource_group', 'Azure Resource Group', '', '', 1),
(30, 'puppet', 'Puppet', '', '1) Ruby based configuration management tool\r\n2) Configuration code is written using puppet DSL’s and wrapped in modules.\r\n3) More sys admin centric\r\n4) Puppet agent on all servers to be configured and pulls the compiled module from the puppet server and installs required software packages specified in the module.', 1),
(31, 'chef', 'Chef', '', '1) Ruby based configuration management tool\r\n2)  infrastructure as code\r\n3) Uses “recipes” and “cookbooks” through its Ruby-based DSL.\r\n4) Provisions virtual machines and configures them according to the rules in cookbooks. \r\n5) An agent running on servers will pull the cookbooks from the chef master server and runs those configurations on the server to reach its desired state.', 1),
(32, 'ansible', 'Ansible', '', '1) Infrastructure automation tool created by Red Hat\r\n2) Help model infrastructure by describing components and systems relate to one another, as opposed to managing systems independently.\r\n3) Do not use Agents \r\n4) Code written in YAML in form of Ansible Playbooks', 1),
(33, 'selenium', 'Selenium Automation Testing', '', '1) Enables automated testing of web applications across various browsers/platforms.\r\n2) Ability to automate selenium testing with Jenkins', 1),
(34, 'jmeter', 'JMeter', '', '1) Load test functional behavior and measure performance on static pages, dynamic resources, and web applications.\r\n2) Can be used to simulate a heavy load on a server or group of servers, database, or network to test its strength, or to analyze overall performance under different load types.\r\n3) To test performance of both static resources such as JavaScript and HTML, as well as dynamic resources, such as JSP, Servlets, and AJAX.', 1),
(35, 'docker', 'Docker', '', '', 1),
(36, 'tfs', 'TFS', '', '1) Integrated suite of developer tools, build system, metrics, version control \r\n2) Range of collaborative tools for software development which can be integrated with current development environment.\r\n3) Using TFS, rework on software under development can be reduced due to increased transparency.\r\n4) TFS operates as the essential point of contact for both process management and project management.', 1),
(37, 'new_relic', 'New Relic', '', '1) Monitors compute resources, storage, and network, and measure inventory usage, and health of an infrastructure\'s resources.', 1),
(38, 'elk_stack', 'ELK Stack', '', '', 1),
(39, 'mingle', 'ThoughtWorks Mingle', '', '1) Combination of few tools (Mingle + Go + Gauge) from ThoughtWorks studios results in an adaptive approach for Agile ALM project management solution.\r\n2) Mingle is an Agile Project management product that facilitates all sizes of companies to put agile systems into practice like defining the objectives of an organization, tracking the progress of plans, efficient problem solving etc.\r\n3) Go is an Agile release management solution that supports open source continuous delivery server for modeling the complex workflows and dependency management.\r\n3) Gauge is a simple, reconcile and collaborative open source test automation tool used to write the test cases in business language. This is possible because of its pluggable architecture.', 1),
(40, 'clearchase', 'IBM - ClearCase, ClearQuest', '', '', 1),
(41, 'MicroFocus', 'MicroFocus (Borland Division) ', NULL, '1) Lean, Agile and DevOps software and solutions\r\n2) Micro Focus Connect (Formerly Borland Connect) is used to achieve the impending software delivery from the team by improving their efficiency.\r\n3) Deliver Apps with Speed, Quality, and Scale\r\n4) Provides robust tracking & reporting and seamless integration of various project related tasks\r\n5) Allows detailed project analysis and effective management.\r\n6) ALM can connect to email systems and send emails about any changes to all desired team members', 1),
(42, 'Trello', 'Trello', NULL, 'Based on Kanban methodology', 1),
(43, 'CodeBeamer', 'CodeBeamer', NULL, '1) Integrations with MS Office, JIRA, IBM DOORS, Enterprise Architect using a REST API\r\n2) Advanced Requirement Workflows & Process Enforcement\r\n3 )Efficient collaboration using documents management features\r\n4) Agile Planning Board enables the convenient planning and management of releases\r\n5) Release and Devops support.\r\n6) End to End Demand Management and Compliance support\r\n7) Associate with source code, tasks, bugs, tests, releases and all other artifacts', 1),
(44, 'Kovair_ALM', 'Kovair ALM Studio ', NULL, '1) comprehensive Application Lifecycle Management product\r\n2) Adopt 100% web-based solution with no client-side software for reducing support burden\r\n3) Development methodologies waterfall, agile or hybrid\r\n4) Configurable task based workflow engine for increased efficiency and productivity\r\n5) Get real-time notifications at every actionable stage\r\n6) Complete coverage of development, enabling compliance with standards.\r\n7) Allow real-time viewing of artifacts status which increases transparency and releases predictability.', 1),
(45, 'SwiftALM', 'SwiftALM', NULL, '1) Managing IT and software projects in the Global Delivery Model.\r\n2) Setup the resources, processes, and projects, control access to plans and reports\r\n3) Integrated Process Governance supports, Agile, waterfall and plenty of other processes\r\n4) Highly configurable and flexible Application Architecture to support thousands of users\r\n5) Advanced Search and Analytics technologies to increase Productivity, Quality and Delivery performance.', 1),
(46, 'Helix_ALM ', 'Helix ALM ', NULL, '1) Centralize and manage requirements, test cases, and issues.\r\n2) Increase Visibility into Project Health\r\n3) Reduces product development risk by allowing collaboration across teams and departments\r\n4) Streamline Development and QA Processes\r\n5) Traceability across all work Items and Data\r\n6) Deep integration with Source Control Systems.', 1),
(47, 'TeamForge', 'TeamForge', NULL, '1) ALM platform for collaborative software development.\r\n2) Maintains standards of governance, compliance, and IP security.\r\n3) Provides visibility and traceability into agile processes and development across the organization\r\n4) Agile processes and encourages tighter collaboration\r\n5) Integrate with other 3rd party tools for centralized document management\r\n6) Role-based access control\r\n7) Visualize Progress with Task Boards\r\n8) Scrum/Kanban Support', 1),
(48, 'SilkRoad', 'SilkRoad', NULL, '1) High-reliability ALM. \r\n2) Interlinking routes for the various legacy management system. \r\n3) Can act as requirement and test management tool.\r\n4) Provide support for Version Control & Comparison of Requirements Documents\r\n5) Requirements Impact Analysis\r\n6) Data Integration between Task, Issue and Test System\r\n7) Manage Requirements including Images, Tables & Equations\r\n8) Upstream or Downstream Traceability Management\r\n9) Change History Management\r\n10) Widely used ALM in mission critical Aerospace and Defence industries.', 1),
(49, 'TFS_SCM', 'TFS Source Control', NULL, '1) Complete version control feature set.\r\n2) Powerful branching and merging.\r\n3) Shelving\r\n4) Check-in policies', 1),
(50, 'AWS_CodeCommit', 'AWS CodeCommit', NULL, '1) Fully-managed source control service that hosts secure Git-based repositiories. \r\n2) Eliminates the need to operate your own source control system or worry about scaling its infrastructure.\r\n3) Supports all Git commands and works with your existing Git tools. \r\n4) Allow implement workflows that include code reviews and feedback.', 1),
(51, 'TeamCity', 'TeamCity (JetBrains)', NULL, '1) Java-based solution,\r\n2) Offers the best .NET support\r\n3) Mature', 1),
(52, 'Travis_CI', 'Travis CI', NULL, '1) Travis CI is free for all open source projects hosted on the GitHub \r\n2) Builds are configured using .travis.yml file\r\n3) Supports a variety of different languages', 1),
(53, 'Go_CD', 'Go CD (ThoughtWorks)', NULL, '1) Uses concept of pipelines which makes modeling of complex build workflows easy.', 1),
(54, 'Bamboo', 'Bamboo (Atlassian)', NULL, '1) Native support for JIRA and BitBucket \r\n2) Support import Jenkins configurations into the Bamboo', 1),
(55, 'GitLab_CI', 'GitLab CI', NULL, '1) Integral part of the open-source Rails project GitLab\r\n2) Gully integrated with GitLab \r\n3) Easily hook projects using the GitLab API\r\n4) Can run multiple jobs concurrently and has inbuilt Docker support. ', 1),
(56, 'Circle_CI', 'Circle CI', NULL, '1) Cloud alternative\r\n2) Currently only supports GitHub and the list of supported languages includes Java, Ruby/Rails, Python, Node.js, PHP, Haskell, and Skala.\r\n3) Main pricing block for the CircleCI is the \"container\". ', 1),
(57, 'CodeShip', 'CodeShip', NULL, '1) Powerful hosted solution with docker support, flexible plans suited both for small teams and enterprises alike.', 1),
(58, 'CodeFresh', 'CodeFresh', NULL, '1) Codefresh designed and built from the ground up specifically with the containers in mind.\r\n2) Provide option to choose from several different templates to ease the migration of projects to Docker containers. \r\n3) UI is clean and intuitive, there is almost no need to parse through the documentation to get started.\r\n4) Facilitates launching your images to a stage-like environment. \r\n5) Easy to use tool with Docker containers at its core and feature of launching the built Docker images to the hosted environment.', 1),
(59, 'MakeFile', 'MakeFile', NULL, '1) Building tool that runs on Unix, Linux, and their flavors\r\n2) Utilise user-defined makefiles.\r\n3) Needs understanding of programming language such as C and C++. ', 1),
(60, 'NANT', 'NANT', NULL, '1) Build tool for .NET projects?', 1),
(61, 'Terraform', 'Terraform', NULL, '1) Cloud-agnostic\r\n2) Uses concept of State files for state management\r\n3)  Use HCL (Hashicorp configuration language) as DSL\r\nHCL is JSON-compatible\r\n4) Custom functionalities\r\n5) Infrastructure as code', 1),
(62, 'Saltstack', 'Saltstack', NULL, '1) Python based opens configuration management tool.\r\n2) Supports remote execution of commands. (Push model)\r\n3) Code (IaC) can be pushed to many nodes simultaneously\r\n4) \"infrastructure as data\" approach\r\n5)  Declarative configuration patterns written in Python are language-agnostic', 1),
(63, 'Juju', 'Juju', NULL, '1) IaC tool \r\n2) Create Juju charms, which are sets of scripts that deploy and operate software, and bundles, which are collections of charms linked together to deploy entire app infrastructures all at once.', 1),
(64, 'Vagrant', 'Vagrant', NULL, '1) IaC tool built by HashiCorp\r\n2) Quickly and easily creats development environments that use small amount of VMs', 1),
(65, 'Docker', 'Docker', NULL, '1) Concept of process level virtualization\r\n2) Creates isolated environments for applications called containers.\r\n3) Containers can be shipped to any other server without making changes to the application\r\n5) YAML is used to create configuration files called Dockerfiles. \r\n6) Dockerfiles are blueprints to build container images that include everything – code, runtime, system tools and libraries, and settings – needed to run a piece of software.', 1),
(66, 'ARM', 'Azure Resource Groups (ARM)', NULL, NULL, 1),
(67, 'Karma', 'Karma', NULL, '1) Karma is a tool which lets us spawn browsers and run jasmine tests inside of them all from the command line. \r\n2) Results of the tests are also displayed on the command line.\r\n3) Karma can also watch for development files for changes and re-run the tests automatically.\r\n4) Karma allows to run jasmine tests as part of a development tool chain which requires tests to be runnable and results inspectable via the command line.\r\n5) Through the Angular CLI it handles the configuration.', 1),
(68, 'SmartBear', 'SmartBear', NULL, '1) SoapUI Pro: Write, run, integrate and automate advanced API tests\r\n2) LoadUI Pro: Ensure APIs perform flawlessly under various traffic conditions\r\n3) ServiceV Pro: Eliminate dependencies by virtualizing the APIs \r\n4) SwaggerHub: Design, build and manage APIs, collaboratively and interactively\r\n5) TestComplete (UI): Functional Test Automation for Desktop, Mobile and Web\r\n6) CrossBrowserTesting: Web-based, mobile and desktop browser testing.\r\n7) Hiptest: Collaborate on an idea, test continuously, and generate living docs', 1),
(69, 'TestPlant', 'TestPlant (EggPlant)', NULL, '1) Eggplant Functional: Image capture, Scripting, Testing methods etc\r\n2) Eggplant AI:  Machine Learning testing tool to auto generate test cases.\r\n3) Eggplant Performance: Load and Performance testing tools.', 1),
(70, 'Checkmarx', 'Checkmarx', NULL, '1) Supports Static Application Security Testing (SAST), also known as white-box testing\r\n2) Source Code Analysis to scan un-compiled code, enabling auditors and developers to receive immediate, accurate feedback on the code.', 1),
(71, 'BinSkim', 'BinSkim', NULL, '1) Binary static analysis tool that scans Windows Portable Executable \r\n(PE) files for security and correctness.  \r\n2) Some of the mitigations ensure binary is \r\na) SafeSEH enabled for safe exception handling,\r\nb) ASLR enabled so that memory is not laid out in a predictable fashion easier and\r\nc) Stack Protection is enabled to prevent overflow', 1),
(72, 'HPE_Fortify_SCA', 'HPE Fortify’s SCA', NULL, '1) Static application security testing\r\n2) Find security issues early in the development cycle and fix at the speed of DevOps (less effort, less time)', 1),
(73, 'Visual_Studio_test ', 'Visual Studio Test ', NULL, '1) Unit testing: Rich set of built in project templates, and test frameworks support multiple platforms\r\n2) IntelliTest: Reducec effort to create and maintain unit tests for new or existing code\r\n3) Live Unit Tesing: Refactor and change code while Live Unit Testing. Automatically execute impacted tests as you edit code to ensure changes do not break tests.\r\n4) UI Testing: Automate tests that drive application through its user interface (UI).\r\n5) Load and Web Performance Testing: Scale tests to hundreds of thousands of concurrent users and generate load from multiple regions worldwide.\r\n6) Code Coverage Analysis: Visualize and report on line level and block level code coverage for both managed and native applications.\r\n7) Fakes: Rich isolation framework that allows to replace any .NET method with a delegate. The Fakes Framework in Visual Studio supports unit testing by providing isolation by way of detours and stubs.', 1),
(74, 'Rapise', 'Rapise', NULL, '1) Support for web, mobile and desktop applications and a wide variety of third-party component libraries.\r\n2) Rapise includes a powerful and easy to use visual language called RVL (Rapise Visual Language) that lets you write automated tests without any programming code.\r\n3) Rapise provides a powerful automated test recorder that captures your interactions with the application being tested and uses that to build a reusable object repository and automated test script.\r\n4) When you record a test, Rapise translates your actions into a script. When you playback the test, the script is executed.\r\n5) Rapise lets you add verification points to your test scripts so that you can make sure your tests are producing the expected results and behavior during testing. \r\n6) Data Driven Testing: \r\n7) Hybrid Application Testing: Rapise can test applications that use multiple different technologies seamlessly.\r\n8) Distributed Testing: Manage distributed automated test lab. Enable run test scripts across multiple planforms and environments with integrated scheduling and real-time reporting.', 1),
(75, 'SoapUI', 'SoapUI', NULL, '1) Functional Testing tool for SOAP and REST testing. \r\n2) Allows to rapidly create and execute automated functional, regression, and load tests. \r\n3) Service Simulation (Mocking): SoapUI MockServices let you mimic and create robust tests against SOAP and REST Web Services before they are implemented. \r\n4) Security Testing: SQL Injection, XML Bomb\r\n5) Load Testing', 1),
(76, 'Facilita', 'Facilita', NULL, '1) Targets a wide range of technologies including Web/HTTP, Web Services, client-side Java, client-side .Net, Citrix, GUI replay, and network level messaging. \r\n2) Supports a comprehensive and growing list of protocols, standards and data formats including; HTTP/HTTPS, SOAP, XML, JSON and Ajax.\r\n3) Recording and intelligent script creation\r\n4) Monitor and chart Web-specific metrics in real-time and in post-run reports.', 1),
(77, 'Application_Insights', 'Application Insights  (Web, Mobile apps)', NULL, '1) Detect and diagnose exceptions and application performance issues\r\n2) Seamlessly integrate with your DevOps pipeline using Visual Studio Team Services, GitHub and webhooks\r\n3) Monitor Azure websites, including those hosted in containers, plus websites on-premises and with other cloud providers\r\n4) Interactive data analytics: Detect trends in application performance and behaviour, identify usage patterns \r\n5) Machine Learning: Use power of machine learning to continually analyse application telemetry.\r\n6) Azure Diagnostics: Proactively detect and diagnose role lifecycle issues—recycle, hung, not started.\r\n7) DevOps integration: Diagnose problems from within your development environment and incorporate monitoring in DevOps processes.', 1),
(78, 'HockeyApp', 'HockeyApp (Mobile Apps)', NULL, '1) Use of Crash Report for stack traces and environment details. \r\n2) App insights: User Metrics to improve apps and measure success.', 1),
(79, 'MS_COM', 'Microsoft Systems Center Operations Manager', NULL, '1) Helps deploys, configures, manages and monitors the operations, services, devices and applications.\r\n2) Uses agents to be installed on each system to check performance and collect data retrieved by the management server.', 1),
(80, 'Nagios', 'Nagios', NULL, '1) Track logs\r\n2) Identify and Resolve infrastructure problems proactively\r\n3) Monitors and troubleshoot Server Performance Issues\r\n4) Plan infrastructure upgrades before outdated systems cause failures\r\n5) Automatically fix problems when detected', 1),
(81, 'Zabbix', 'Zabbix', NULL, '1) Network, Server, Cloud, Services monitoring\r\n2) Agentless monitoring of user services\r\n3) Monitor thousands of similar devices by using configuration templates\r\n4) Distributed Monitoring\r\n5) Automate Zabbix management via API (Integration capability)', 1),
(82, 'Sensu', 'Sensu', NULL, '1) Sensu integrates with the tools and technologies like Nagios plugins.\r\n2) Monitor application and system services\r\n3) Sensu check format is composed of an exit status code, and an arbitrary payload (e.g. message string, PerfData, JSON, animated cat GIFs, etc). This provides a single platform to collect every metric data point that is meaningful to business.', 1),
(83, 'Prometheus', 'Prometheus', NULL, '1) Systems and service monitoring system\r\n2) Timeseries collection happens via a pull model over HTTP\r\n3) Targets are discovered via service discovery or static configuration\r\n4) Services that need to be monitored using Prometheus should expose a Prometheus metrics endpoint. \r\n5) Prometheus also does not offer durable long-term storage, anomaly detection, automatic horizontal scaling and user management. \r\n6) Prometheus is not a dashboarding solution, it features a simple UI for experimentation with PromQL queries but relies on Grafana for dashboarding, adding some additional setup complexity.', 1),
(84, 'SysDig', 'SysDig', NULL, '1) Complete approach to monitoring and troubleshooting containers and Kubernetes.\r\n2) Enhance software reliability and accelerate problem resolution, with advanced Kubernetes integration and built-in Prometheus monitoring capabilities.\r\n3) Response times, application performance metrics, custom metrics, container, server and network utilization metrics, and orchestrator metrics.\r\n4) Full-stack dashboards to visualize applications, microservices, containers, networks, and more.\r\n5) Alerts across namespaces, clusters, labels, metrics, or any tag. \r\n6) In-depth troubleshooting. Deep views per process, container, connection down to payload.', 1),
(85, 'AppDynamics', 'AppDynamics', NULL, '1) Monitor Java, .NET, PHP and Node.JS applications', 1),
(86, 'BigPanda', 'BigPanda', NULL, '1) Out-of-the-box solutions for monitoring platform data aggregation, \r\nand cross analysis. \r\n2) Modernized user experience with great UIs and system alerts showing correlations between events.', 1),
(87, 'PagerDuty', 'PagerDuty', NULL, '1) Out-of-the-box solutions for monitoring platform data aggregation, \r\nand cross analysis. \r\n2)  PagerDuty enables management of alerts and on-call management.', 1);

-- --------------------------------------------------------

--
-- Table structure for table `phase_tool`
--

DROP TABLE IF EXISTS `phase_tool`;
CREATE TABLE IF NOT EXISTS `phase_tool` (
  `phase_tool_id` int(11) NOT NULL AUTO_INCREMENT,
  `phase_id` int(11) NOT NULL,
  `tool_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`phase_tool_id`),
  KEY `tool_id` (`tool_id`),
  KEY `phase_id` (`phase_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `phase_tool`
--

INSERT INTO `phase_tool` (`phase_tool_id`, `phase_id`, `tool_id`, `is_active`) VALUES
(1, 1, 1, 1),
(2, 1, 5, 1),
(3, 1, 4, 1),
(4, 1, 6, 1),
(5, 1, 7, 1),
(6, 1, 8, 1),
(7, 1, 9, 1),
(8, 2, 2, 1),
(9, 2, 3, 1),
(11, 2, 10, 1),
(12, 2, 11, 1),
(13, 3, 16, 1),
(14, 3, 12, 1),
(15, 3, 13, 1),
(16, 3, 14, 1),
(17, 3, 15, 1),
(18, 3, 17, 1),
(19, 3, 18, 1),
(20, 3, 19, 1),
(21, 3, 20, 1),
(22, 3, 21, 1),
(23, 4, 22, 1),
(24, 4, 23, 1),
(25, 4, 24, 1),
(26, 4, 25, 1),
(27, 4, 26, 1),
(28, 5, 27, 1),
(29, 5, 28, 1),
(30, 5, 29, 1),
(31, 5, 30, 1),
(32, 5, 31, 1),
(33, 5, 32, 1),
(34, 6, 13, 1),
(35, 6, 14, 1),
(36, 6, 15, 1),
(37, 6, 18, 1),
(38, 6, 19, 1),
(39, 6, 20, 1),
(40, 6, 21, 1),
(41, 7, 13, 1),
(42, 7, 14, 1),
(43, 7, 15, 1),
(44, 7, 18, 1),
(45, 7, 19, 1),
(46, 7, 20, 1),
(47, 7, 21, 1),
(48, 6, 33, 1),
(49, 6, 34, 1),
(50, 7, 33, 1),
(51, 7, 34, 1),
(52, 8, 30, 1),
(53, 8, 31, 1),
(54, 8, 32, 1),
(55, 8, 35, 1),
(56, 8, 36, 1),
(57, 9, 37, 1),
(58, 9, 38, 1),
(59, 1, 39, 1),
(60, 1, 40, 1),
(61, 1, 41, 1),
(62, 1, 42, 1),
(63, 1, 43, 1),
(64, 1, 44, 1),
(65, 1, 45, 1),
(66, 1, 46, 1),
(67, 1, 47, 1),
(68, 1, 48, 1),
(69, 1, 36, 1),
(70, 2, 49, 1),
(71, 2, 50, 1),
(72, 3, 51, 1),
(73, 3, 52, 1),
(74, 3, 53, 1),
(75, 3, 54, 1),
(76, 3, 55, 1),
(77, 3, 56, 1),
(78, 3, 57, 1),
(79, 3, 58, 1),
(80, 3, 59, 1),
(81, 3, 60, 1),
(82, 5, 61, 1),
(83, 5, 62, 1),
(84, 5, 63, 1),
(85, 5, 64, 1),
(86, 5, 65, 1),
(87, 5, 66, 1),
(88, 6, 67, 1),
(89, 6, 68, 1),
(90, 6, 69, 1),
(91, 6, 70, 1),
(92, 6, 71, 1),
(93, 6, 72, 1),
(94, 6, 73, 1),
(95, 6, 74, 1),
(96, 6, 75, 1),
(97, 6, 76, 1),
(98, 7, 67, 1),
(99, 7, 68, 1),
(100, 7, 69, 1),
(101, 7, 70, 1),
(102, 7, 71, 1),
(103, 7, 72, 1),
(104, 7, 73, 1),
(105, 7, 74, 1),
(106, 7, 75, 1),
(107, 7, 76, 1),
(108, 9, 77, 1),
(109, 9, 78, 1),
(110, 9, 79, 1),
(111, 9, 80, 1),
(112, 9, 81, 1),
(113, 9, 82, 1),
(114, 9, 83, 1),
(115, 9, 84, 1),
(116, 9, 85, 1),
(117, 9, 86, 1),
(118, 9, 87, 1);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `phase_tool`
--
ALTER TABLE `phase_tool`
  ADD CONSTRAINT `phase_tool_ibfk_2` FOREIGN KEY (`tool_id`) REFERENCES `master_tool` (`tool_id`),
  ADD CONSTRAINT `phase_tool_ibfk_3` FOREIGN KEY (`phase_id`) REFERENCES `master_phase` (`phase_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
