-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 03, 2018 at 05:37 AM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `assessment`
--

-- --------------------------------------------------------

--
-- Table structure for table `assessment`
--

DROP TABLE IF EXISTS `assessment`;
CREATE TABLE IF NOT EXISTS `assessment` (
  `assessment_id` int(11) NOT NULL AUTO_INCREMENT,
  `assessment_token` varchar(50) NOT NULL,
  `assessment_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `account_name` varchar(50) NOT NULL,
  `project_name` varchar(50) NOT NULL,
  `automation_status` varchar(25) NOT NULL,
  `devops_platform` varchar(25) NOT NULL,
  `summary` text NOT NULL,
  `assessed_by` int(11) DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`assessment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `assessment_environments`
--

DROP TABLE IF EXISTS `assessment_environments`;
CREATE TABLE IF NOT EXISTS `assessment_environments` (
  `assessment_environment_id` int(11) NOT NULL AUTO_INCREMENT,
  `assessment_id` int(11) NOT NULL,
  `environment` varchar(50) NOT NULL,
  `applicable` tinyint(4) NOT NULL COMMENT 'true = 1 and false =0',
  `managed_by` varchar(50) NOT NULL,
  `auto_deploy` varchar(100) NOT NULL,
  `remarks` text NOT NULL,
  PRIMARY KEY (`assessment_environment_id`),
  KEY `assessment_id` (`assessment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `assessment_phase`
--

DROP TABLE IF EXISTS `assessment_phase`;
CREATE TABLE IF NOT EXISTS `assessment_phase` (
  `assessment_phase_id` int(11) NOT NULL AUTO_INCREMENT,
  `assessment_id` int(11) NOT NULL,
  `phase_id` int(11) NOT NULL,
  `phase_name` varchar(50) NOT NULL,
  `automation_status` varchar(25) NOT NULL,
  `processes` text NOT NULL,
  `automation_satisfaction` varchar(25) NOT NULL,
  `observations` text NOT NULL,
  `reasons` text NOT NULL,
  `special_remarks` text NOT NULL,
  PRIMARY KEY (`assessment_phase_id`),
  KEY `assessment_id` (`assessment_id`),
  KEY `phase_id` (`phase_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `assessment_phase_tools`
--

DROP TABLE IF EXISTS `assessment_phase_tools`;
CREATE TABLE IF NOT EXISTS `assessment_phase_tools` (
  `assessment_phase_tool_id` int(11) NOT NULL AUTO_INCREMENT,
  `assessment_phase_id` int(11) NOT NULL,
  `assessment_id` int(11) NOT NULL,
  `tool_name` varchar(50) NOT NULL,
  `version` varchar(50) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`assessment_phase_tool_id`),
  KEY `assessment_phase_id` (`assessment_phase_id`),
  KEY `assessment_id` (`assessment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `assessment_recommendations`
--

DROP TABLE IF EXISTS `assessment_recommendations`;
CREATE TABLE IF NOT EXISTS `assessment_recommendations` (
  `assessment_recommendation_id` int(11) NOT NULL AUTO_INCREMENT,
  `assessment_id` int(11) NOT NULL,
  `title` text,
  `description` text,
  `added_on` datetime NOT NULL,
  PRIMARY KEY (`assessment_recommendation_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `master_phase`
--

DROP TABLE IF EXISTS `master_phase`;
CREATE TABLE IF NOT EXISTS `master_phase` (
  `phase_id` int(11) NOT NULL AUTO_INCREMENT,
  `phase_identity` varchar(50) NOT NULL,
  `phase_name` varchar(50) NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`phase_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `master_tool`
--

DROP TABLE IF EXISTS `master_tool`;
CREATE TABLE IF NOT EXISTS `master_tool` (
  `tool_id` int(11) NOT NULL AUTO_INCREMENT,
  `tool_identity` varchar(50) NOT NULL,
  `tool_name` varchar(50) NOT NULL,
  `version` varchar(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`tool_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `phase_tool`
--

DROP TABLE IF EXISTS `phase_tool`;
CREATE TABLE IF NOT EXISTS `phase_tool` (
  `phase_tool_id` int(11) NOT NULL AUTO_INCREMENT,
  `phase_id` int(11) NOT NULL,
  `tool_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`phase_tool_id`),
  KEY `tool_id` (`tool_id`),
  KEY `phase_id` (`phase_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `phase_tool`
--
ALTER TABLE `phase_tool`
  ADD CONSTRAINT `phase_tool_ibfk_2` FOREIGN KEY (`tool_id`) REFERENCES `master_tool` (`tool_id`),
  ADD CONSTRAINT `phase_tool_ibfk_3` FOREIGN KEY (`phase_id`) REFERENCES `master_phase` (`phase_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
